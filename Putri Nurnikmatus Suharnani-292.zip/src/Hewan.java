public class Hewan {
    String nama;
    String jenis;
    string suara;

    public
}
